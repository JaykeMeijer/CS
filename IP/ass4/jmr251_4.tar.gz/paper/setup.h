#define BASEPHP            "localhost"
#define BASECGI            "localhost/cgi"
#define HOTEL_GATEWAY_ADDR "localhost"
#define HOTEL_GATEWAY_PORT 1337
#define PAPERSERVER_ADDR   "localhost"
#define PAPERSERVER_PORT   1338
