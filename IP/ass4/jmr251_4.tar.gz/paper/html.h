#include <stdio.h>

void html_header(char*);
void html_close();
void html_404();
