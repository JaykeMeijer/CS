<?php
$BASEPHP            = "localhost";
$BASECGI            = "localhost/paper";
$HOTEL_GATEWAY_ADDR = "localhost";
$HOTEL_GATEWAY_PORT = 1337;
$PAPERSERVER_ADDR   = "localhost";
$PAPERSERVER_PORT   = 1338;
?>
